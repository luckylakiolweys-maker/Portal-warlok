# Portal Warlok

Portal berita responsif dengan dashboard admin, publikasi berita, arsip, dan agenda.

## Menjalankan
1. Install Node.js 18+.
2. Ekstrak folder proyek.
3. Jalankan `npm install`.
4. Salin `.env.example` menjadi `.env`.
5. Isi `ADMIN_PASSWORD` dengan password admin pilihan Anda dan ganti `SESSION_SECRET` dengan nilai acak yang panjang.
6. Jalankan `npm start` lalu buka `http://localhost:3000`.

Data disimpan dalam `data.json` dan dibuat otomatis saat konten pertama disimpan.

**Keamanan:** jangan unggah file `.env` ke GitHub atau membagikan password. Gunakan HTTPS saat dipasang online. Untuk produksi, ganti penyimpanan JSON dan session memory dengan database serta session store persisten.
