require("dotenv").config();
const express=require("express"), session=require("express-session"), bcrypt=require("bcryptjs");
const fs=require("fs"), path=require("path");
const app=express(), DB=path.join(__dirname,"data.json");
app.use(express.json({limit:"2mb"}));
app.use(session({secret:process.env.SESSION_SECRET||"change-this-secret",resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:8*60*60*1000}}));
function read(){try{return JSON.parse(fs.readFileSync(DB,"utf8"))}catch{return {articles:[],events:[]}}}
function write(d){fs.writeFileSync(DB,JSON.stringify(d,null,2))}
function auth(req,res,next){if(!req.session.admin)return res.status(401).json({error:"Silakan login sebagai admin."});next()}
app.use(express.static(path.join(__dirname,"public")));
app.post("/api/login",(req,res)=>{const p=String(req.body.password||"");if(!process.env.ADMIN_PASSWORD)return res.status(500).json({error:"ADMIN_PASSWORD belum diatur di file .env"});if(p!==process.env.ADMIN_PASSWORD)return res.status(401).json({error:"Password tidak sesuai."});req.session.admin=true;res.json({ok:true})});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/session",(req,res)=>res.json({authenticated:!!req.session.admin}));
app.get("/api/articles",(req,res)=>res.json(read().articles.sort((a,b)=>b.createdAt-a.createdAt)));
app.post("/api/articles",auth,(req,res)=>{const d=read(),{title,category,excerpt,content,image,author}=req.body;if(!title||!content)return res.status(400).json({error:"Judul dan isi berita wajib diisi."});const a={id:Date.now().toString(),title,category:category||"Berita",excerpt:excerpt||"",content,image:image||"",author:author||"Redaksi Portal Warlok",createdAt:Date.now()};d.articles.unshift(a);write(d);res.json(a)});
app.delete("/api/articles/:id",auth,(req,res)=>{const d=read();d.articles=d.articles.filter(a=>a.id!==req.params.id);write(d);res.json({ok:true})});
app.get("/api/events",(req,res)=>res.json(read().events));
app.post("/api/events",auth,(req,res)=>{const d=read();d.events.unshift({id:Date.now().toString(),title:req.body.title,date:req.body.date,description:req.body.description||""});write(d);res.json({ok:true})});
app.delete("/api/events/:id",auth,(req,res)=>{const d=read();d.events=d.events.filter(x=>x.id!==req.params.id);write(d);res.json({ok:true})});
const port=process.env.PORT||3000;app.listen(port,()=>console.log(`Portal Warlok berjalan di http://localhost:${port}`));